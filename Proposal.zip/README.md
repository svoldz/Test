# ResepMasakan
Aplikasi Resep Masakan Sederhana

# Tutorial Build
https://rivaldi48.blogspot.com/2020/03/tutorial-membuat-aplikasi-resep-masakan-dengan-android-studio.html

# Tutorial Build Video
https://www.youtube.com/watch?v=8-vLekzZXVU
